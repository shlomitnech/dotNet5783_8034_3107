﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Targil0
{
    partial class Program3107
    {
        static partial void Welcome3107()
        {
            Console.WriteLine("I am also here!");
        }
    }
}
