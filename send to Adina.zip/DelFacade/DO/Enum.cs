﻿namespace DO;

public struct Enums
{

    public enum Category {Bread, Dips, MainCourse, Sides, Desserts };
    public enum Action  {Add, Update, getItem, GetList, Delete, readOrder };
    public enum Type {Product, Order, OrderItem };

}
