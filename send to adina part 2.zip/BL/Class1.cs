﻿namespace BL
{
    public class Class1
    {

    }
}